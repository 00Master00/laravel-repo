import 'package:flutter/material.dart';
import 'package:myapp/start_screen.dart';

void main() {
  runApp(const MaterialApp(
      home: StartScreen(), // เรียก StartScreen โดยตรง
    )
  );
}
